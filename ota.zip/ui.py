# ui.py  –  Genesis text UI  v3.0
# ─────────────────────────────────────────────────────────────────────────────
# Layout : 368×448  font vga2_bold_16x32 (16×32 px)  → 23 cols × 12 rows
#   y=0..31   status bar  │  y=32..33 separator  │  y=34.. content
#
# Navigation
#   Touch  : tap item to move selection; tap again to activate
#            top-left corner (<80,<80) = back
#   BOOT   : tap = next   double-tap = back   hold 1.5s = select
#            hold 3s (anywhere) = Power menu
#
# New in v3.0
#   Splash screen, scrollable menus, power menu (sleep/reboot/shutdown/
#   USB-JTAG/OTA), volume + UI sounds, 5 colour themes, SNTP sync,
#   timezone (UTC offset), on-screen manual time entry, SD card tools.
# ─────────────────────────────────────────────────────────────────────────────

import utime
import network
import gc
try:
    import ujson as json
except ImportError:
    import json
import vga2_bold_16x32 as _FONT_MOD

# ── Grid constants ─────────────────────────────────────────────────────────────
FW   = _FONT_MOD.WIDTH    # 16
FH   = _FONT_MOD.HEIGHT   # 32
W    = 368
H    = 448
COLS = W // FW            # 23
BAR_H  = FH               # 32  status bar
SEP_H  = 2
CONT_Y = BAR_H + SEP_H   # 34  first content pixel row
CONT_H = H - CONT_Y      # 414
CONT_ROWS = CONT_H // FH  # 12  content text rows (0-11)
_VISIBLE  = 9             # max item rows visible in a scrollable menu

SETTINGS_FILE = '/settings.json'
BOOT_BTN_PIN  = 0

# ── Colour palette (module-level; updated by _apply_theme) ────────────────────
BLACK  = 0x0000;  WHITE  = 0xFFFF;  GREY   = 0x4228
CYAN   = 0x07FF;  YELLOW = 0xFFE0;  GREEN  = 0x07E0
RED    = 0xF800;  ORANGE = 0xFC60;  DKBLUE = 0x000C

C_BG        = BLACK
C_FG        = WHITE
C_STATUS_BG = DKBLUE
C_STATUS_FG = CYAN
C_SEL_BG    = 0x0318
C_SEL_FG    = WHITE
C_DIM       = GREY
C_OK        = GREEN
C_WARN      = ORANGE
C_ACCENT    = CYAN
C_TITLE_BG  = DKBLUE
C_TITLE_FG  = YELLOW

# ── Colour themes ─────────────────────────────────────────────────────────────
_THEMES = {
    'Default': {
        'bg':0x0000,'fg':0xFFFF,'status_bg':0x000C,'status_fg':0x07FF,
        'sel_bg':0x0318,'sel_fg':0xFFFF,'accent':0x07FF,'dim':0x4228,
        'title_bg':0x000C,'title_fg':0xFFE0,
    },
    'Hacker': {
        'bg':0x0000,'fg':0x07E0,'status_bg':0x0200,'status_fg':0x07E0,
        'sel_bg':0x0280,'sel_fg':0xFFFF,'accent':0x07E0,'dim':0x02C0,
        'title_bg':0x0200,'title_fg':0x07E0,
    },
    'Ocean': {
        'bg':0x000C,'fg':0xC7FF,'status_bg':0x000F,'status_fg':0xFFFF,
        'sel_bg':0x0439,'sel_fg':0xFFFF,'accent':0x4FFF,'dim':0x2145,
        'title_bg':0x000F,'title_fg':0xC7FF,
    },
    'Sunset': {
        'bg':0x2000,'fg':0xFDE0,'status_bg':0x4000,'status_fg':0xFD20,
        'sel_bg':0x8200,'sel_fg':0xFFFF,'accent':0xFD20,'dim':0x6180,
        'title_bg':0x4000,'title_fg':0xFD20,
    },
    'Ice': {
        'bg':0x0810,'fg':0xE71C,'status_bg':0x1082,'status_fg':0x87FF,
        'sel_bg':0x2145,'sel_fg':0xFFFF,'accent':0x87FF,'dim':0x4208,
        'title_bg':0x1082,'title_fg':0xE71C,
    },
}
_THEME_NAMES = list(_THEMES.keys())

def _apply_theme(name):
    """Overwrite module-level colour globals from a theme dict."""
    global C_BG, C_FG, C_STATUS_BG, C_STATUS_FG, C_SEL_BG, C_SEL_FG
    global C_DIM, C_OK, C_WARN, C_ACCENT, C_TITLE_BG, C_TITLE_FG
    t = _THEMES.get(name, _THEMES['Default'])
    C_BG        = t['bg'];     C_FG        = t['fg']
    C_STATUS_BG = t['status_bg'];  C_STATUS_FG = t['status_fg']
    C_SEL_BG    = t['sel_bg']; C_SEL_FG    = t['sel_fg']
    C_ACCENT    = t['accent']; C_DIM       = t['dim']
    C_TITLE_BG  = t['title_bg'];   C_TITLE_FG  = t['title_fg']
    # These stay constant across themes:
    C_OK   = 0x07E0;  C_WARN = 0xFC60

# ── Helpers ───────────────────────────────────────────────────────────────────

def _pad(s, n):
    s = str(s)
    return s[:n] if len(s) >= n else s + ' ' * (n - len(s))

def _load_settings():
    try:
        with open(SETTINGS_FILE) as f:
            return json.loads(f.read())
    except Exception:
        return {}

def _load_wifi_conf():
    """Parse /wifi.conf → list of (ssid, password) in priority order.

    File format (one entry per line, highest priority first):
        MyNetwork:MyPassword
        OpenNet:
        # comment lines are ignored
    """
    nets = []
    try:
        with open('/wifi.conf') as f:
            for line in f.read().splitlines():
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if ':' in line:
                    idx = line.index(':')
                    ssid = line[:idx].strip()
                    pwd  = line[idx+1:].strip()
                    if ssid:
                        nets.append((ssid, pwd))
    except OSError:
        pass
    return nets

def _save_settings(cfg):
    try:
        with open(SETTINGS_FILE, 'w') as f:
            f.write(json.dumps(cfg))
    except Exception:
        pass

# ── I2S beep helper (module-level buffers built once) ─────────────────────────
_SND_SELECT = None   # short high beep
_SND_NAV    = None   # very short tick

def _build_sounds():
    global _SND_SELECT, _SND_NAV
    # 16kHz 16-bit stereo (LE) square waves
    def square_wave(freq, dur_ms, amp=5000):
        n   = dur_ms * 16  # samples @ 16kHz
        buf = bytearray(n * 4)
        half = max(1, 16000 // freq // 2)
        for i in range(n):
            v = amp if (i // half) % 2 == 0 else -amp
            # little-endian i16 × 2 channels
            lo = v & 0xFF;  hi = (v >> 8) & 0xFF
            j = i * 4
            buf[j]=lo; buf[j+1]=hi; buf[j+2]=lo; buf[j+3]=hi
        return bytes(buf)
    try:
        _SND_SELECT = square_wave(880, 55)
        _SND_NAV    = square_wave(440, 20)
    except Exception:
        _SND_SELECT = _SND_NAV = None

_build_sounds()


class UI:
    """Genesis text-mode UI v3.0.  Touch + BOOT-button navigation."""

    # ── Menu definitions ──────────────────────────────────────────────────────
    _HOME = [
        ("Apps",          'apps'),
        ("Settings",      'settings'),
        ("WiFi",          'wifi'),
        ("Web Server",    'webserver'),
        ("Power...",      'power'),
        ("About",         'about'),
    ]
    _APPS = [
        ("Clock",             'app_clock'),
        ("Calendar",          'app_calendar'),
        ("Calculator",        'app_calc'),
        ("GIF Player",        'app_gif'),
        ("JPG Viewer",        'app_jpg'),
        ("MP3 Player",        'app_mp3'),
        ("WirePilot Probe",   'app_buspirate'),
        ("Script Launcher",   'app_launcher'),
        ("< Back",            'back'),
    ]
    _SETTINGS = [
        # ── Display ──────────────────────────────────────────────────────────
        ("Brightness  -",       'bright_down'),
        ("Brightness  +",       'bright_up'),
        ("Theme...",            'theme'),
        ("Invert (dark/light)", 'invert'),
        ("Display off  (2s)",   'disp_off'),
        # ── Audio ─────────────────────────────────────────────────────────────
        ("Volume  -",           'vol_down'),
        ("Volume  +",           'vol_up'),
        ("Mute toggle",         'mute'),
        ("UI sounds",           'sounds_toggle'),
        # ── Time ──────────────────────────────────────────────────────────────
        ("Sync time (NTP)",     'ntp_sync'),
        ("Timezone  UTC+?",     'timezone'),
        ("Set time...",         'set_time_manual'),
        # ── SD card ───────────────────────────────────────────────────────────
        ("SD: mount",           'sd_mount'),
        ("SD: unmount",         'sd_unmount'),
        ("SD: info / list",     'sd_info'),
        ("< Back",              'back'),
    ]
    _WIFI = [
        ("WiFi on",    'wifi_on'),
        ("WiFi off",   'wifi_off'),
        ("Scan...",    'wifi_scan'),
        ("Status",     'wifi_status'),
        ("< Back",     'back'),
    ]
    _POWER = [
        ("Sleep  (display off)", 'pwr_sleep'),
        ("Reboot",               'pwr_reboot'),
        ("Shutdown",             'pwr_shutdown'),
        ("USB JTAG / Flash mode",'pwr_jtag'),
        ("OTA update...",        'pwr_ota'),
        ("Exit to main.py",      'pwr_exit'),
        ("< Cancel",             'back'),
    ]

    # ── init ──────────────────────────────────────────────────────────────────
    def __init__(self, hw):
        self.hw      = hw
        self._d      = hw.display
        self._raw    = hw.display._disp
        self._touch  = hw.touch
        self._pmu    = hw.pmu
        self._rtc    = hw.rtc

        self._screen  = 'home'
        self._sel     = 0
        self._scroll  = 0          # menu scroll offset
        self._prev_screens = []    # back-stack

        self._cfg        = _load_settings()
        self._brightness = self._cfg.get('brightness', 200)
        self._inverted   = self._cfg.get('inverted', False)
        self._volume     = self._cfg.get('volume', 70)
        self._muted      = self._cfg.get('muted', False)
        self._sounds_on  = self._cfg.get('sounds', True)
        self._tz_offset  = self._cfg.get('tz_offset', 0)   # hours, int
        self._theme_name = self._cfg.get('theme', 'Default')
        _apply_theme(self._theme_name)

        # Button manager (PWR + BOOT)
        try:
            from machine import Pin
            from button_manager import ButtonManager
            _boot_pin = Pin(BOOT_BTN_PIN, Pin.IN, Pin.PULL_UP)
            self._buttons = ButtonManager(
                boot_pin = _boot_pin,
                io_exp   = getattr(hw, 'io_exp', None),
                pmu      = getattr(hw, 'pmu', None),
            )
        except Exception as e:
            print("[ui] ButtonManager init failed:", e)
            self._buttons = None

        # WiFi STA – try wifi.conf first, fall back to settings.json
        try:
            self._wlan = network.WLAN(network.STA_IF)
            if not self._wlan.isconnected():
                self._wlan.active(True)
                # Build priority network list from /wifi.conf then settings.json
                nets = _load_wifi_conf()
                saved_ssid = self._cfg.get('wifi_ssid', '')
                saved_pwd  = self._cfg.get('wifi_pwd',  '')
                if saved_ssid:
                    nets.append((saved_ssid, saved_pwd))
                for ssid, pwd in nets:
                    if ssid:
                        self._wlan.connect(ssid, pwd) if pwd else self._wlan.connect(ssid)
                        break   # non-blocking; status shown in status bar
        except Exception:
            self._wlan = None

        self._d.set_brightness(self._brightness)
        self._raw.fill(C_BG)

        # Saved WiFi nets from scan
        self._wifi_nets     = []
        self._wifi_scan_sel = 0

        # Time-set state
        self._ts_vals = [2026, 1, 1, 0, 0, 0]   # Y M D H M S
        self._ts_sel  = 0

    # ── Beep ──────────────────────────────────────────────────────────────────

    def _beep(self, kind='nav'):
        if not self._sounds_on or self._muted:
            return
        try:
            i2s = self.hw.i2s
            if i2s is None:
                return
            buf = _SND_SELECT if kind == 'select' else _SND_NAV
            if buf:
                i2s.write(buf)
        except Exception:
            pass

    # ── Low-level draw ────────────────────────────────────────────────────────

    def _t(self, s, col, row, fg=None, bg=None):
        if fg is None: fg = C_FG
        if bg is None: bg = C_BG
        x = col * FW
        y = CONT_Y + row * FH
        if y + FH > H or x >= W:
            return
        avail = max(1, (W - x) // FW - 1)
        self._raw.text(_FONT_MOD, _pad(s, avail), x, y, fg, bg)

    def _st(self, s, x, fg=None, bg=None):
        if fg is None: fg = C_STATUS_FG
        if bg is None: bg = C_STATUS_BG
        if x >= W: return
        avail = max(1, (W - x) // FW - 1)
        self._raw.text(_FONT_MOD, _pad(s, avail), x, 0, fg, bg)

    def _fill_row(self, row, color=None):
        if color is None: color = C_BG
        y = CONT_Y + row * FH
        if y + FH <= H:
            self._raw.fill_rect(0, y, W, FH, color)

    def _clear(self):
        self._raw.fill_rect(0, CONT_Y, W, CONT_H, C_BG)

    # ── Status bar ────────────────────────────────────────────────────────────

    # ── Status bar helpers ────────────────────────────────────────────────────

    def _draw_wifi_icon(self, x, y):
        """Draw a 24×18 WiFi fan icon at (x,y). Uses RSSI for signal strength."""
        d = self._raw
        # Determine level 0-4
        level = 0
        if self._wlan is not None:
            try:
                if self._wlan.isconnected():
                    rssi = self._wlan.status('rssi')
                    if   rssi > -55: level = 4
                    elif rssi > -65: level = 3
                    elif rssi > -75: level = 2
                    else:            level = 1
                elif self._wlan.active():
                    level = 0   # active but not connected
            except Exception:
                level = 0
        dim = C_DIM
        # Draw 4 arcs as thick horizontal lines (simplified fan)
        # Centre dot
        cx = x + 12;  cy = y + 16
        d.fill_rect(cx - 1, cy, 3, 3, C_OK if level > 0 else dim)
        # Arc radii  (r=4, 8, 12, 16) — each drawn as a short hline at top
        for i, r in enumerate((4, 8, 12, 16)):
            col = C_OK if level > i else dim
            bx = cx - r;  by = cy - r
            # top arc approximated by 3 rows of rect with clipped width
            aw = max(2, r)
            d.hline(cx - aw, by,     aw * 2, col)
            d.hline(cx - aw + 1, by + 1, aw * 2 - 2, col)

    def _draw_batt_icon(self, x, y):
        """Draw a 34×16 battery icon at (x,y) with fill level and charging bolt."""
        d = self._raw
        pct = -1
        chg = False
        if self._pmu:
            try:
                pct = self._pmu.get_battery_percent()
                chg = self._pmu.is_charging()
            except Exception:
                pass
        # Colours
        if pct < 0:
            fill_col = C_DIM;  border_col = C_DIM
        elif chg:
            fill_col = 0x07FF;  border_col = 0x07FF   # cyan = charging
        elif pct > 60:
            fill_col = C_OK;    border_col = C_OK      # green
        elif pct > 25:
            fill_col = 0xFFE0;  border_col = 0xFFE0   # yellow
        else:
            fill_col = 0xF800;  border_col = 0xF800   # red

        # Body: 30×14 at (x,y+1)  +  nub: 3×6 at (x+30, y+4)
        bw = 30;  bh = 14
        d.rect(x, y + 1, bw, bh, border_col)
        d.fill_rect(x + bw, y + 5, 3, 4, border_col)

        # Fill bar (inside body, 1px inset)
        if pct >= 0:
            fw = max(0, (pct * (bw - 2)) // 100)
            d.fill_rect(x + 1, y + 2, fw, bh - 2, fill_col)

        # Charging bolt  ⚡  — 3-pixel-wide zigzag
        if chg:
            bc = 0xFFFF   # white
            # top half
            d.vline(x + 17, y + 2, 5, bc)
            d.vline(x + 16, y + 3, 4, bc)
            # bottom half
            d.vline(x + 15, y + 7, 5, bc)
            d.vline(x + 14, y + 7, 5, bc)

        # Percentage text right of icon (small: 2 chars + %)
        label = "{}%".format(pct) if pct >= 0 else "--"
        tx = x + bw + 6
        for ci, ch in enumerate(label):
            self._raw.text(ch, tx + ci * FW, y, border_col)

    def _time_str(self):
        if self._rtc:
            try:
                t = self._rtc.get_datetime()
                if t:
                    h = (t[3] + self._tz_offset) % 24
                    return "{:02d}:{:02d}:{:02d}".format(h, t[4], t[5])
            except Exception:
                pass
        s = utime.ticks_ms() // 1000
        return "{:02d}:{:02d}:{:02d}".format(s // 3600 % 24, s // 60 % 60, s % 60)

    def _draw_indicator_dots(self, x, y):
        """Draw 4 status dots (r=5) spaced 14px apart at (x, y centre).
        BT=blue  SD=pink  USB=purple  OTA=orange  — grey when inactive."""
        d   = self._raw
        DIM = 0x39E7   # dark grey
        r   = 5
        gap = 14

        # ── Bluetooth ─────────────────────────────────────────────────────────
        bt_col = DIM
        try:
            import bluetooth
            bt = bluetooth.BLE()
            if bt.active():
                bt_col = 0x001F   # blue
        except Exception:
            pass

        # ── SD card ───────────────────────────────────────────────────────────
        sd_col = DIM
        try:
            import os
            os.stat('/sd')
            sd_col = 0xF81F   # pink / magenta
        except Exception:
            pass

        # ── USB connected ─────────────────────────────────────────────────────
        usb_col = DIM
        try:
            pmu = getattr(self, '_pmu', None)
            if pmu and pmu.get_vbus_mv() > 3800:
                usb_col = 0x780F   # purple
        except Exception:
            pass

        # ── OTA available ─────────────────────────────────────────────────────
        ota_col = DIM
        try:
            import ota_check
            if ota_check.available():
                ota_col = 0xFC00   # orange
        except Exception:
            pass

        for i, col in enumerate((bt_col, sd_col, usb_col, ota_col)):
            cx = x + i * gap + r
            d.fill_rect(cx - r, y - r, r * 2 + 1, r * 2 + 1, C_STATUS_BG)  # clear
            d.circle(cx, y, r, col)
            if col != DIM:
                d.circle(cx, y, r - 1, col)   # filled look

    def _draw_status(self, title=None):
        d = self._raw
        d.fill_rect(0, 0, W, BAR_H, C_STATUS_BG)
        # WiFi icon — far left (24×18)
        self._draw_wifi_icon(4, (BAR_H - 18) // 2)
        # Indicator dots — just right of wifi icon
        self._draw_indicator_dots(34, BAR_H // 2)
        # Clock — centred
        tim = self._time_str()
        cx  = (W - len(tim) * FW) // 2
        self._st(tim, cx, fg=WHITE, bg=C_STATUS_BG)
        # Battery icon — right side
        self._draw_batt_icon(W - 4 - 30 - 6 - 4 * FW, (BAR_H - 16) // 2)
        d.hline(0, BAR_H,     W, C_ACCENT)
        d.hline(0, BAR_H + 1, W, C_DIM)

    # ── Splash screen ─────────────────────────────────────────────────────────

    def _show_splash(self):
        d = self._raw
        d.fill(C_BG)
        # Thin animated border
        for r in range(0, min(W, H) // 2, 6):
            col = self._raw.colorRGB(0, max(0, 80 - r * 2), max(0, 120 - r * 2))
            d.rect(r, r, W - 2*r, H - 2*r, col)
            utime.sleep_ms(8)

        # Logo text – centred
        lines = [
            (2,  "  GENESIS  ",  C_ACCENT,   C_BG),
            (4,  "  S3 / Xenon", C_FG,       C_BG),
            (6,  "  MicroPython",C_DIM,       C_BG),
            (7,  "  v3.0 FW   ", C_DIM,       C_BG),
        ]
        for row, text, fg, bg in lines:
            cx = max(0, (W - len(text.strip()) * FW) // 2)
            d.text(_FONT_MOD, text.strip(), cx, CONT_Y + row * FH, fg, bg)
            utime.sleep_ms(60)

        # Hardware quick-info
        try:
            import psram as _pr
            mem = _pr.size() // (1024*1024)
        except Exception:
            mem = 0
        info = [
            "ESP32-S3  240MHz",
            "{}MB PSRAM  16MB Flash".format(mem),
            "368x448 SH8601 AMOLED",
        ]
        for i, line in enumerate(info):
            self._t(" " + line, 0, 9 + i, C_DIM, C_BG)
            utime.sleep_ms(40)

        utime.sleep_ms(900)
        # Fade out by clearing
        d.fill(C_BG)

    # ── Scrollable menu ───────────────────────────────────────────────────────

    def _items(self):
        return {
            'home':     self._HOME,
            'apps':     self._APPS,
            'settings': self._SETTINGS,
            'wifi':     self._WIFI,
            'power':    self._POWER,
        }.get(self._screen, [])

    def _clamp_scroll(self, items):
        """Ensure _scroll keeps _sel visible."""
        if self._sel < self._scroll:
            self._scroll = self._sel
        elif self._sel >= self._scroll + _VISIBLE:
            self._scroll = self._sel - _VISIBLE + 1
        self._scroll = max(0, min(self._scroll, max(0, len(items) - _VISIBLE)))

    def _draw_menu(self, title=None):
        self._clear()
        items = self._items()

        if self._screen == 'home':
            self._t("  ** GENESIS **  ", 0, 0, C_ACCENT, C_BG)
            self._t("tap=next hold=sel", 0, 1, C_DIM, C_BG)
            self._t("", 0, 2, C_BG, C_BG)
            off = 3
            # Home never overflows (6 items ≤ CONT_ROWS-3=9)
            for i, (label, _) in enumerate(items):
                row = off + i
                if row >= CONT_ROWS: break
                if i == self._sel:
                    self._fill_row(row, C_SEL_BG)
                    self._t(">" + _pad(label, COLS-2), 1, row, C_SEL_FG, C_SEL_BG)
                else:
                    self._fill_row(row, C_BG)
                    self._t(" " + _pad(label, COLS-2), 1, row, C_FG, C_BG)
            return

        # ── Scrollable submenu ────────────────────────────────────────────────
        t = title or ("[{}]".format(self._screen.upper()))
        self._t(_pad(t, COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)

        self._clamp_scroll(items)

        # Scroll-up indicator
        if self._scroll > 0:
            self._t(_pad("↑ ({} more)".format(self._scroll), COLS),
                    0, 1, C_DIM, C_BG)
        else:
            self._fill_row(1, C_BG)

        # Visible items (rows 2 .. 2+_VISIBLE-1 = row 10)
        for vi in range(_VISIBLE):
            idx = self._scroll + vi
            row = 2 + vi
            if idx >= len(items):
                self._fill_row(row, C_BG)
                continue
            label, _ = items[idx]
            if idx == self._sel:
                self._fill_row(row, C_SEL_BG)
                self._t(">" + _pad(label, COLS-2), 1, row, C_SEL_FG, C_SEL_BG)
            else:
                self._fill_row(row, C_BG)
                self._t(" " + _pad(label, COLS-2), 1, row, C_FG, C_BG)

        # Scroll-down indicator (row 11)
        remaining = len(items) - (self._scroll + _VISIBLE)
        if remaining > 0:
            self._t(_pad("↓ ({} more)".format(remaining), COLS),
                    0, CONT_ROWS-1, C_DIM, C_BG)
        else:
            self._fill_row(CONT_ROWS-1, C_BG)

    def _draw_info(self, title, lines, footer="tap/btn=back"):
        """Display a static info screen. Scrolls if lines > visible rows."""
        self._clear()
        self._t(_pad(title, COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
        visible = CONT_ROWS - 3   # rows 2..(CONT_ROWS-2) available
        scroll  = getattr(self, '_info_scroll', 0)
        scroll  = max(0, min(scroll, max(0, len(lines) - visible)))
        self._info_scroll = scroll
        for i in range(visible):
            idx = i + scroll
            row = i + 2
            text = lines[idx] if idx < len(lines) else ""
            self._t(_pad(text, COLS), 0, row, C_FG, C_BG)
        # scroll indicator
        if len(lines) > visible:
            ind = "  [{}/{}]".format(scroll + 1, len(lines) - visible + 1)
            self._t(_pad(ind + " " + footer, COLS), 0, CONT_ROWS-1, C_DIM, C_BG)
        else:
            self._t(_pad(footer, COLS), 0, CONT_ROWS-1, C_DIM, C_BG)

    # ── Screen helpers ────────────────────────────────────────────────────────

    def _push(self, screen, sel=0, scroll=0):
        self._prev_screens.append((self._screen, self._sel, self._scroll))
        self._screen = screen
        self._sel    = sel
        self._scroll = scroll

    def _pop(self):
        if self._prev_screens:
            self._screen, self._sel, self._scroll = self._prev_screens.pop()
        else:
            self._screen = 'home'
            self._sel = self._scroll = 0

    def _go_back(self):
        self._pop()
        self._draw_menu()
        self._draw_status()

    def _show_screen(self, name, sel=0):
        self._push(name, sel, 0)
        self._draw_menu()

    # ── WiFi sub-screens ──────────────────────────────────────────────────────

    def _show_wifi_status(self):
        lines = []
        if self._wlan is None:
            lines = ["  WiFi not available"]
        else:
            try:
                lines.append("  Active:    {}".format("yes" if self._wlan.active() else "no"))
                lines.append("  Connected: {}".format("yes" if self._wlan.isconnected() else "no"))
                if self._wlan.isconnected():
                    cfg  = self._wlan.ifconfig()
                    ssid = self._wlan.config('ssid') or ''
                    lines += ["  IP:   {}".format(cfg[0]),
                               "  GW:   {}".format(cfg[2]),
                               "  SSID: {}".format(ssid[:14])]
                    try:
                        lines.append("  RSSI: {} dBm".format(self._wlan.status('rssi')))
                    except Exception:
                        pass
            except Exception as e:
                lines.append("  Err: {}".format(e))
        self._draw_info("[WiFi Status]", lines)
        self._info_scroll = 0; self._screen = 'wifi_status'

    def _show_wifi_scan(self):
        self._screen = 'wifi_scan'
        self._clear()
        self._t(_pad("[Scanning...]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
        nets = []
        if self._wlan:
            try:
                if not self._wlan.active():
                    self._wlan.active(True);  utime.sleep_ms(300)
                raw = self._wlan.scan()
                raw.sort(key=lambda x: -x[3])
                for n in raw[:8]:
                    try: ssid = n[0].decode('utf-8', 'replace')
                    except Exception: ssid = str(n[0])
                    nets.append((ssid, n[3]))
            except Exception:
                pass
        self._wifi_nets     = nets
        self._wifi_scan_sel = 0
        self._clear()
        self._t(_pad("[WiFi Scan]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
        if nets:
            self._t(_pad("hold=connect", COLS), 0, 1, C_DIM, C_BG)
            for i, (ssid, rssi) in enumerate(nets):
                q  = "***" if rssi > -60 else ("** " if rssi > -75 else "*  ")
                bg = C_SEL_BG if i == 0 else C_BG
                fg = C_SEL_FG if i == 0 else C_FG
                self._fill_row(i+2, bg)
                self._t("{} {}".format(q, _pad(ssid, COLS-5)), 0, i+2, fg, bg)
        else:
            self._t("  No networks found", 0, 3, C_WARN, C_BG)

    def _wifi_scan_move(self, new_sel):
        nets = self._wifi_nets
        if not nets: return
        old = self._wifi_scan_sel
        self._wifi_scan_sel = new_sel % len(nets)
        for idx in (old, self._wifi_scan_sel):
            ssid, rssi = nets[idx]
            q  = "***" if rssi > -60 else ("** " if rssi > -75 else "*  ")
            bg = C_SEL_BG if idx == self._wifi_scan_sel else C_BG
            fg = C_SEL_FG if idx == self._wifi_scan_sel else C_FG
            self._fill_row(idx+2, bg)
            self._t("{} {}".format(q, _pad(ssid, COLS-5)), 0, idx+2, fg, bg)

    def _wifi_connect_selected(self):
        nets = self._wifi_nets
        sel  = self._wifi_scan_sel
        if sel < 0 or sel >= len(nets): return
        ssid = nets[sel][0]
        pwd  = self._cfg.get('wifi_pwd', '') if self._cfg.get('wifi_ssid','') == ssid else ''
        self._clear()
        self._t(_pad("[Connecting...]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
        self._t("  SSID: " + ssid[:16], 0, 2, C_FG, C_BG)
        self._t("  (use set_wifi() for pwd)", 0, 3, C_DIM, C_BG)
        try:
            if self._wlan:
                self._wlan.active(True);  self._wlan.connect(ssid, pwd)
                for _ in range(20):
                    utime.sleep_ms(500)
                    if self._wlan.isconnected(): break
                if self._wlan.isconnected():
                    ip = self._wlan.ifconfig()[0]
                    self._cfg['wifi_ssid'] = ssid;  _save_settings(self._cfg)
                    self._t("  Connected!", 0, 5, C_OK, C_BG)
                    self._t("  IP: " + ip, 0, 6, C_OK, C_BG)
                else:
                    self._t("  Failed - check password", 0, 5, RED, C_BG)
        except Exception as e:
            self._t("  Err: " + str(e)[:18], 0, 5, RED, C_BG)
        utime.sleep_ms(2500)
        self._screen = 'wifi';  self._sel = 0;  self._scroll = 0
        self._draw_menu("[WiFi]")

    # ── Web server ────────────────────────────────────────────────────────────

    def _show_webserver(self):
        self._screen = 'webserver'
        self._clear()
        self._t(_pad("[Web Server]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
        self._t("  Starting AP...", 0, 2, C_WARN, C_BG)
        try:
            import webserver
            ip = webserver.start_ap()
            self._clear()
            self._t(_pad("[Web Server ON]", COLS), 0, 0, C_OK, C_TITLE_BG)
            for i, l in enumerate(["  AP: Genesis-S3","  PW: genesis123",
                                    "  IP: " + ip,"  http://" + ip,
                                    "","  Upload / manage files",
                                    "  Hold btn to stop"]):
                self._t(_pad(l, COLS), 0, i+2, C_FG, C_BG)
            self._draw_status()
            webserver.run(stop_fn=self._stop_requested)
            webserver.stop()
        except Exception as e:
            self._clear()
            self._t(_pad("[Web Server ERR]", COLS), 0, 0, RED, C_TITLE_BG)
            err = str(e)
            for i in range(0, min(len(err), COLS*4), COLS):
                self._t(err[i:i+COLS], 0, i//COLS+2, RED, C_BG)
            utime.sleep_ms(3000)
        self._screen = 'home';  self._sel = 0;  self._scroll = 0
        self._draw_menu()

    def _stop_requested(self):
        if self._buttons:
            ev = self._buttons.poll()
            if ev in ('back', 'esc', 'rev'):
                return True
        if self._touch:
            try:
                if self._touch.get_first_touch(): return True
            except Exception: pass
        return False

    # ── Settings actions ──────────────────────────────────────────────────────

    def _vol_change(self, delta):
        self._volume = max(0, min(100, self._volume + delta))
        self._cfg['volume'] = self._volume
        _save_settings(self._cfg)
        if self.hw.codec:
            try: self.hw.codec.set_volume(self._volume)
            except Exception: pass
        self._draw_menu("[Settings]")

    def _ntp_sync(self):
        self._clear()
        self._t(_pad("[NTP Sync]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
        if self._wlan is None or not self._wlan.isconnected():
            self._t("  WiFi not connected", 0, 2, RED, C_BG)
            self._t("  Connect via WiFi menu first", 0, 3, C_DIM, C_BG)
            utime.sleep_ms(2500)
            self._draw_menu("[Settings]");  return
        self._t("  Syncing with pool.ntp.org ...", 0, 2, C_WARN, C_BG)
        try:
            import ntptime
            ntptime.host = "pool.ntp.org"
            ntptime.settime()   # sets machine.RTC to UTC
            # Copy to hardware RTC if available
            if self._rtc:
                import utime as _ut
                t = _ut.gmtime()
                # t = (Y, M, D, H, Min, S, wday, yday)
                self._rtc.set_time(t[0], t[1], t[2], t[3], t[4], t[5])
            self._t("  Done! UTC time set.", 0, 3, C_OK, C_BG)
            self._t("  " + self._time_str(), 0, 4, C_ACCENT, C_BG)
        except Exception as e:
            self._t("  Failed: " + str(e)[:20], 0, 3, RED, C_BG)
        utime.sleep_ms(2500)
        self._draw_menu("[Settings]")

    def _show_timezone(self):
        """Scrollable list of UTC offsets -12 .. +14."""
        self._screen = 'timezone'
        self._sel    = self._tz_offset + 12   # index in [-12..+14]
        self._scroll = max(0, self._sel - _VISIBLE // 2)
        self._clear()
        self._t(_pad("[Timezone UTC offset]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
        self._t(_pad("Current: UTC{:+d}".format(self._tz_offset), COLS), 0, 1, C_DIM, C_BG)
        self._tz_items = [("UTC{:+d}".format(h), h) for h in range(-12, 15)]
        self._clamp_scroll_custom(len(self._tz_items))
        for vi in range(_VISIBLE):
            idx = self._scroll + vi
            row = 2 + vi
            if idx >= len(self._tz_items):
                self._fill_row(row, C_BG);  continue
            label, _ = self._tz_items[idx]
            if idx == self._sel:
                self._fill_row(row, C_SEL_BG)
                self._t(">" + _pad(label, COLS-2), 1, row, C_SEL_FG, C_SEL_BG)
            else:
                self._fill_row(row, C_BG)
                self._t(" " + _pad(label, COLS-2), 1, row, C_FG, C_BG)

    def _clamp_scroll_custom(self, total):
        if self._sel < self._scroll:
            self._scroll = self._sel
        elif self._sel >= self._scroll + _VISIBLE:
            self._scroll = self._sel - _VISIBLE + 1
        self._scroll = max(0, min(self._scroll, max(0, total - _VISIBLE)))

    def _show_set_time_manual(self):
        """On-screen time/date adjuster."""
        self._screen = 'set_time_manual'
        # Seed from RTC if available
        if self._rtc:
            try:
                t = self._rtc.get_datetime()
                if t:
                    self._ts_vals = [t[0], t[1], t[2], t[3], t[4], t[5]]
            except Exception:
                pass
        self._ts_sel = 0
        self._draw_set_time()

    def _draw_set_time(self):
        self._clear()
        self._t(_pad("[Set Time/Date]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
        self._t("tap=next  hold=+  dbl=-", 0, 1, C_DIM, C_BG)
        labels = ["Year ","Month","Day  ","Hour ","Min  ","Sec  "]
        ranges = [(2000,2099),(1,12),(1,31),(0,23),(0,59),(0,59)]
        for i, (label, val) in enumerate(zip(labels, self._ts_vals)):
            row = i + 2
            fg  = C_SEL_FG if i == self._ts_sel else C_FG
            bg  = C_SEL_BG if i == self._ts_sel else C_BG
            self._fill_row(row, bg)
            self._t("{}  {:4d}   {:4d}-{:4d}".format(
                label, val, ranges[i][0], ranges[i][1]),
                0, row, fg, bg)
        row = len(labels) + 2
        self._fill_row(row, C_BG)
        self._t(" [Apply & Save]", 0, row, C_OK, C_BG)
        self._fill_row(row+1, C_BG)
        self._t(" [Cancel]", 0, row+1, C_WARN, C_BG)

    def _ts_increment(self, idx, delta=1):
        ranges = [(2000,2099),(1,12),(1,31),(0,23),(0,59),(0,59)]
        lo, hi = ranges[idx]
        self._ts_vals[idx] = lo + (self._ts_vals[idx] - lo + delta) % (hi - lo + 1)
        self._draw_set_time()

    def _ts_apply(self):
        Y, Mo, D, H, Mi, S = self._ts_vals
        if self._rtc:
            try: self._rtc.set_time(Y, Mo, D, H, Mi, S)
            except Exception: pass
        try:
            import machine
            machine.RTC().datetime((Y, Mo, D, 0, H, Mi, S, 0))
        except Exception:
            pass

    def _show_sd_info(self):
        self._clear()
        self._t(_pad("[SD Card Info]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
        if self.hw.sd is None:
            self._t("  SD not initialised", 0, 2, C_WARN, C_BG)
            self._t("  Use 'SD: mount' first", 0, 3, C_DIM, C_BG)
            self._t(_pad("tap/btn=back", COLS), 0, CONT_ROWS-1, C_DIM, C_BG)
            self._screen = 'sd_info';  return
        try:
            import os
            stat = os.statvfs('/sd')
            total = stat[0] * stat[2] // (1024*1024)
            free  = stat[0] * stat[3] // (1024*1024)
            files = os.listdir('/sd')
            lines = [
                "  Total: {} MB".format(total),
                "  Free:  {} MB".format(free),
                "  Files: {}".format(len(files)),
                "",
            ]
            for f in files[:6]:
                lines.append("  " + f[:20])
            if len(files) > 6:
                lines.append("  ... ({} more)".format(len(files)-6))
            for i, l in enumerate(lines):
                row = i + 2
                if row >= CONT_ROWS-1: break
                self._t(_pad(l, COLS), 0, row, C_FG, C_BG)
        except Exception as e:
            self._t("  Error: " + str(e)[:20], 0, 2, RED, C_BG)
        self._t(_pad("tap/btn=back", COLS), 0, CONT_ROWS-1, C_DIM, C_BG)
        self._screen = 'sd_info'

    def _show_theme_select(self):
        self._screen = 'theme'
        try:
            self._sel = _THEME_NAMES.index(self._theme_name)
        except ValueError:
            self._sel = 0
        self._scroll = 0
        self._clear()
        self._t(_pad("[Colour Theme]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
        for i, name in enumerate(_THEME_NAMES):
            row = i + 2
            if row >= CONT_ROWS-1: break
            if i == self._sel:
                self._fill_row(row, C_SEL_BG)
                self._t(">" + _pad(name + (" ✓" if name == self._theme_name else ""), COLS-2),
                        1, row, C_SEL_FG, C_SEL_BG)
            else:
                self._fill_row(row, C_BG)
                self._t(" " + _pad(name, COLS-2), 1, row, C_FG, C_BG)

    # ── Power menu actions ────────────────────────────────────────────────────

    def _power_sleep(self):
        self._clear()
        self._t("Sleeping... tap to wake", 0, 4, C_DIM, C_BG)
        self._raw.disp_off()
        # Wait for touch or button press
        while True:
            if self._buttons:
                ev = self._buttons.poll()
                if ev:
                    utime.sleep_ms(100);  break
            if self._touch:
                try:
                    if self._touch.get_first_touch():
                        utime.sleep_ms(200);  break
                except Exception: pass
            utime.sleep_ms(50)
        self._raw.disp_on()
        self._draw_status()
        self._screen = 'home';  self._sel = 0;  self._scroll = 0
        self._draw_menu()

    def _power_reboot(self):
        self._clear()
        self._t("  Rebooting...", 0, 4, C_WARN, C_BG)
        utime.sleep_ms(800)
        import machine;  machine.reset()

    def _power_shutdown(self):
        self._clear()
        self._t("  Shutting down...", 0, 4, C_WARN, C_BG)
        utime.sleep_ms(500)
        if self._pmu:
            try: self._pmu.power_off()
            except Exception: pass
        # Fallback: deep sleep indefinitely
        try:
            import machine;  machine.deepsleep()
        except Exception: pass

    def _power_jtag(self):
        self._clear()
        self._t(_pad("[USB JTAG / Flash]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
        lines = [
            "  Entering bootloader...",
            "",
            "  Then use esptool:",
            "  esptool.py write_flash",
            "  0x0 firmware.bin",
            "",
            "  Or use Thonny IDE.",
        ]
        for i, l in enumerate(lines):
            self._t(_pad(l, COLS), 0, i+2, C_FG, C_BG)
        self._draw_status()
        utime.sleep_ms(1500)
        try:
            import machine;  machine.bootloader()
        except Exception:
            # Fallback: reset
            machine.reset()

    def _power_ota(self):
        """OTA update screen: check for updates, show info, offer to download+apply."""
        import ota_check

        def _show(lines, title="[OTA Update]", tcol=None):
            self._clear()
            self._t(_pad(title, COLS), 0, 0,
                    tcol or C_TITLE_FG, C_TITLE_BG)
            for i, (txt, col) in enumerate(lines):
                self._t(_pad(txt, COLS), 0, i + 2, col, C_BG)
            self._draw_status()

        # ── Step 1: show current version + check button ────────────────────
        _show([
            ("  Current: v{}".format(ota_check.VERSION), C_FG),
            ("", C_FG),
            ("  Checking for update...", C_WARN),
        ])
        utime.sleep_ms(200)

        result = ota_check.check(force=True)

        if result.get('error'):
            _show([
                ("  Current: v{}".format(ota_check.VERSION), C_FG),
                ("", C_FG),
                ("  Error:", C_WARN),
                ("  " + str(result['error'])[:COLS-2], RED),
                ("", C_FG),
                ("  Check WiFi connection.", C_DIM),
            ], tcol=RED)
            utime.sleep_ms(3000)

        elif not result.get('available'):
            _show([
                ("  Current: v{}".format(ota_check.VERSION), C_OK),
                ("  Remote:  v{}".format(result.get('version','?')), C_FG),
                ("", C_FG),
                ("  You are up to date!", C_OK),
            ], tcol=C_OK)
            utime.sleep_ms(2500)

        else:
            # Update available — prompt user
            remote_ver = result.get('version', '?')
            notes      = result.get('notes', '')[:COLS-4]
            _show([
                ("  Current: v{}".format(ota_check.VERSION), C_FG),
                ("  Remote:  v{}".format(remote_ver),        C_WARN),
                ("  Notes: " + notes,                        C_DIM),
                ("", C_FG),
                ("  PWR = Install now", C_OK),
                ("  BOOT = Cancel",     C_DIM),
            ], title="[Update Available]", tcol=C_WARN)

            # Wait for PWR (ok) or BOOT (back)
            deadline = utime.ticks_add(utime.ticks_ms(), 30000)
            confirmed = False
            while utime.ticks_diff(deadline, utime.ticks_ms()) > 0:
                ev = self._poll_button()
                if ev in ('ok', 'next'):
                    confirmed = True;  break
                if ev in ('back', 'esc', 'rev'):
                    break
                utime.sleep_ms(20)

            if confirmed:
                status_line = ["  Starting..."]
                def _progress(msg):
                    status_line[0] = "  " + msg[:COLS-2]
                    _show([
                        ("  v{} → v{}".format(ota_check.VERSION, remote_ver), C_WARN),
                        ("", C_FG),
                        (status_line[0], C_OK),
                        ("  Do not power off!", C_DIM),
                    ], title="[Installing]", tcol=C_WARN)
                try:
                    ota_check.download_and_apply('/ota', progress_cb=_progress)
                    # ^ reboots on success — code below only runs on failure
                except Exception as e:
                    _show([
                        ("  Failed:", RED),
                        ("  " + str(e)[:COLS-2], RED),
                    ], title="[OTA Error]", tcol=RED)
                    utime.sleep_ms(3000)

        self._screen = 'home';  self._sel = 0;  self._scroll = 0
        self._draw_menu()

    # ── Action dispatch ───────────────────────────────────────────────────────

    def _action(self, action):
        self._beep('select')

        if action == 'back':
            self._go_back();  return

        # ── Home sub-menus
        if action == 'apps':
            self._show_screen('apps')
        elif action == 'settings':
            self._show_screen('settings')
        elif action == 'wifi':
            self._show_screen('wifi')
        elif action == 'power':
            self._show_screen('power')
        elif action == 'about':
            import sys, os, gc
            import ota_check
            # ── Gather storage stats ──────────────────────────────────────────
            def _fs_free(path):
                try:
                    s = os.statvfs(path)
                    free_kb  = s[0] * s[3] // 1024
                    total_kb = s[0] * s[2] // 1024
                    return "{}/{}KB".format(free_kb, total_kb)
                except Exception:
                    return "n/a"
            flash_free = _fs_free('/')
            sd_free    = _fs_free('/sd')
            user_free  = _fs_free('/user')
            gc.collect()
            ram_free   = "{}/{}KB".format(gc.mem_free() // 1024,
                                          (gc.mem_free() + gc.mem_alloc()) // 1024)
            self._draw_info("[About]", [
                "  Genesis S3 / Xenon",
                "  MicroPython {}".format(sys.version.split(' ')[0] if hasattr(sys,'version') else '1.27'),
                "  FW v{}".format(ota_check.VERSION),
                "  ESP32-S3 @ 240 MHz",
                "  8 MB PSRAM  16 MB Flash",
                "  368x448 AMOLED SH8601",
                "  PMU AXP2101  RTC PCF85063",
                "  IMU QMI8658  Codec ES8311",
                "",
                "  Flash /   free: {}".format(flash_free),
                "  Flash /user:    {}".format(user_free),
                "  SD card:        {}".format(sd_free),
                "  RAM free:       {}".format(ram_free),
            ])
            self._info_scroll = 0; self._screen = 'about'

        # ── App launches
        elif action in ('app_clock','app_calendar','app_calc','app_gif',
                        'app_jpg','app_mp3','app_buspirate','app_launcher'):
            self._run_app(action)

        # ── WiFi
        elif action == 'wifi_on':
            if self._wlan: self._wlan.active(True)
            self._draw_menu("[WiFi]")
        elif action == 'wifi_off':
            if self._wlan: self._wlan.active(False)
            self._draw_menu("[WiFi]")
        elif action == 'wifi_scan':
            self._show_wifi_scan()
        elif action == 'wifi_status':
            self._show_wifi_status()
        elif action == 'webserver':
            self._show_webserver()

        # ── Display/audio settings
        elif action == 'bright_down':
            self._brightness = max(10, self._brightness - 25)
            self._d.set_brightness(self._brightness)
            self._cfg['brightness'] = self._brightness;  _save_settings(self._cfg)
            self._draw_menu("[Settings]")
        elif action == 'bright_up':
            self._brightness = min(255, self._brightness + 25)
            self._d.set_brightness(self._brightness)
            self._cfg['brightness'] = self._brightness;  _save_settings(self._cfg)
            self._draw_menu("[Settings]")
        elif action == 'theme':
            self._show_theme_select()
        elif action == 'invert':
            self._inverted = not self._inverted
            self._raw.invert_color(self._inverted)
            self._cfg['inverted'] = self._inverted;  _save_settings(self._cfg)
        elif action == 'disp_off':
            self._raw.disp_off();  utime.sleep_ms(2000);  self._raw.disp_on()

        elif action == 'vol_down':
            self._vol_change(-10)
        elif action == 'vol_up':
            self._vol_change(+10)
        elif action == 'mute':
            self._muted = not self._muted
            self._cfg['muted'] = self._muted;  _save_settings(self._cfg)
            if self.hw.codec:
                try: self.hw.codec.mute(self._muted)
                except Exception: pass
            self._draw_menu("[Settings]")
        elif action == 'sounds_toggle':
            self._sounds_on = not self._sounds_on
            self._cfg['sounds'] = self._sounds_on;  _save_settings(self._cfg)
            self._draw_menu("[Settings]")

        # ── Time settings
        elif action == 'ntp_sync':
            self._ntp_sync()
        elif action == 'timezone':
            self._show_timezone()
        elif action == 'set_time_manual':
            self._show_set_time_manual()

        # ── SD card
        elif action == 'sd_mount':
            self._clear()
            self._t(_pad("[SD Mount]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
            try:
                if self.hw.sd:
                    self.hw.sd.mount()
                    self._t("  SD mounted at /sd", 0, 2, C_OK, C_BG)
                else:
                    self._t("  SD driver not init", 0, 2, RED, C_BG)
            except Exception as e:
                self._t("  Error: " + str(e)[:20], 0, 2, RED, C_BG)
            utime.sleep_ms(1500);  self._draw_menu("[Settings]")
        elif action == 'sd_unmount':
            self._clear()
            self._t(_pad("[SD Unmount]", COLS), 0, 0, C_TITLE_FG, C_TITLE_BG)
            try:
                if self.hw.sd:
                    self.hw.sd.unmount()
                    self._t("  SD unmounted safely", 0, 2, C_OK, C_BG)
                else:
                    self._t("  SD driver not init", 0, 2, RED, C_BG)
            except Exception as e:
                self._t("  Error: " + str(e)[:20], 0, 2, RED, C_BG)
            utime.sleep_ms(1500);  self._draw_menu("[Settings]")
        elif action == 'sd_info':
            self._show_sd_info()

        # ── Power
        elif action == 'pwr_sleep':    self._power_sleep()
        elif action == 'pwr_reboot':   self._power_reboot()
        elif action == 'pwr_shutdown': self._power_shutdown()
        elif action == 'pwr_jtag':     self._power_jtag()
        elif action == 'pwr_ota':      self._power_ota()
        elif action == 'pwr_exit':     self._exit()

    # ── App runner ────────────────────────────────────────────────────────────

    def _run_app(self, action):
        _MAP = {
            'app_clock':     ('app_clock',     'run'),
            'app_calendar':  ('app_calendar',  'run'),
            'app_calc':      ('app_calc',      'run'),
            'app_gif':       ('app_gifplayer', 'run'),
            'app_jpg':       ('app_jpgviewer', 'run'),
            'app_mp3':       ('app_mp3player', 'run'),
            'app_buspirate': ('app_buspirate', 'run'),
            'app_launcher':  ('app_launcher',  'run'),
        }
        mod_name, fn_name = _MAP[action]
        self._clear()
        self._t(_pad("Loading " + mod_name + "...", COLS), 0, 3, C_ACCENT, C_BG)
        try:
            mod = __import__(mod_name)
            getattr(mod, fn_name)(self.hw)
        except Exception as e:
            self._clear()
            self._t(_pad("[ERROR]", COLS), 0, 0, RED, C_TITLE_BG)
            err = str(e)
            for i in range(0, min(len(err), COLS*5), COLS):
                self._t(err[i:i+COLS], 0, i//COLS+2, RED, C_BG)
            utime.sleep_ms(3000)
        self._pop()   # return to caller screen
        self._draw_menu()
        self._draw_status()

    # ── Input: buttons ───────────────────────────────────────────────────────

    def _poll_button(self):
        """Non-blocking poll via ButtonManager.
        Events:
          PWR single → 'ok'    (select/enter)
          PWR double → 'next'  (next/down)
          PWR long   → 'power' (power menu)
          BOOT single→ 'back'  (go back one screen)
          BOOT double→ 'esc'   (go up in menus)
          BOOT long  → 'rev'   (return to home)
        """
        if not self._buttons:
            return None
        return self._buttons.poll()

    # ── Input: touch ──────────────────────────────────────────────────────────

    def _poll_touch(self):
        if not self._touch:
            return None, -1, -1
        try:
            t = self._touch.get_first_touch()
            if t:
                return 'touch', int(t[0]), int(t[1])
        except Exception:
            pass
        return None, -1, -1

    def _handle_touch(self, tx, ty):
        # Back zone
        if tx < 80 and ty < 80:
            self._beep('nav');  self._go_back();  return

        # Status bar
        if ty < CONT_Y:
            self._draw_status();  return

        row = (ty - CONT_Y) // FH

        # ── Single-purpose screens ────────────────────────────────────────────
        if self._screen in ('about', 'wifi_status', 'sd_info'):
            self._go_back();  return

        if self._screen == 'wifi_scan':
            idx = row - 2
            if 0 <= idx < len(self._wifi_nets):
                if idx == self._wifi_scan_sel:
                    self._wifi_connect_selected()
                else:
                    self._wifi_scan_move(idx)
            return

        if self._screen == 'set_time_manual':
            labels = 6
            if row - 2 == self._ts_sel and 0 <= row - 2 < labels:
                self._ts_increment(self._ts_sel)
            elif 0 <= row - 2 < labels:
                self._ts_sel = row - 2
                self._draw_set_time()
            elif row - 2 == labels:   # Apply
                self._ts_apply()
                self._go_back()
            elif row - 2 == labels + 1:  # Cancel
                self._go_back()
            return

        if self._screen == 'timezone':
            idx = self._scroll + (row - 2)
            items = getattr(self, '_tz_items', [])
            if 0 <= idx < len(items):
                if idx == self._sel:
                    _, offset = items[idx]
                    self._tz_offset = offset
                    self._cfg['tz_offset'] = offset;  _save_settings(self._cfg)
                    self._go_back()
                else:
                    self._sel = idx
                    self._show_timezone()
            return

        if self._screen == 'theme':
            idx = row - 2
            if 0 <= idx < len(_THEME_NAMES):
                if idx == self._sel:
                    name = _THEME_NAMES[idx]
                    self._theme_name = name
                    self._cfg['theme'] = name;  _save_settings(self._cfg)
                    _apply_theme(name)
                    self._go_back()
                    self._raw.fill(C_BG)
                    self._draw_status()
                    self._draw_menu()
                else:
                    self._sel = idx
                    self._show_theme_select()
            return

        # ── Standard menu screens ─────────────────────────────────────────────
        items = self._items()
        if not items:
            return

        if self._screen == 'home':
            off = 3
        else:
            off = 2   # scrollable: items start at row 2

        idx = (row - off) + (self._scroll if self._screen != 'home' else 0)

        if 0 <= idx < len(items):
            if idx == self._sel:
                self._action(items[idx][1])
                if self._screen not in ('set_time_manual', 'timezone', 'theme'):
                    self._draw_status()
            else:
                old = self._sel
                self._sel = idx
                if self._screen == 'home':
                    self._draw_menu()
                else:
                    self._clamp_scroll(items)
                    self._draw_menu()
                self._beep('nav')

    # ── Main navigation helpers ───────────────────────────────────────────────

    def _next_item(self):
        self._beep('nav')
        if self._screen in ('about', 'wifi_status', 'sd_info'):
            self._info_scroll = getattr(self, '_info_scroll', 0) + 1
            self._draw_menu()  # redraws current info screen via _draw_menu dispatch
            return
        if self._screen == 'wifi_scan':
            nets = self._wifi_nets
            if nets:
                self._wifi_scan_move((self._wifi_scan_sel + 1) % len(nets))
            return
        if self._screen == 'timezone':
            items = getattr(self, '_tz_items', [])
            self._sel = (self._sel + 1) % max(1, len(items))
            self._show_timezone();  return
        if self._screen == 'theme':
            self._sel = (self._sel + 1) % len(_THEME_NAMES)
            self._show_theme_select();  return
        if self._screen == 'set_time_manual':
            # cycle through fields then Apply/Cancel rows
            self._ts_sel = (self._ts_sel + 1) % 8
            if self._ts_sel >= 6:
                self._ts_sel = 6
            self._draw_set_time();  return
        items = self._items()
        if items:
            old = self._sel
            self._sel = (self._sel + 1) % len(items)
            self._clamp_scroll(items)
            self._draw_menu()

    def _select_item(self):
        if self._screen == 'wifi_scan':
            self._wifi_connect_selected();  return
        if self._screen == 'set_time_manual':
            if self._ts_sel < 6:
                self._ts_increment(self._ts_sel)
            else:
                self._ts_apply();  self._go_back()
            return
        if self._screen == 'timezone':
            items = getattr(self, '_tz_items', [])
            if 0 <= self._sel < len(items):
                _, offset = items[self._sel]
                self._tz_offset = offset
                self._cfg['tz_offset'] = offset;  _save_settings(self._cfg)
            self._go_back();  return
        if self._screen == 'theme':
            if 0 <= self._sel < len(_THEME_NAMES):
                name = _THEME_NAMES[self._sel]
                self._theme_name = name
                self._cfg['theme'] = name;  _save_settings(self._cfg)
                _apply_theme(name)
                self._raw.fill(C_BG)
            self._go_back();  return
        if self._screen in ('about','wifi_status','sd_info'):
            self._go_back();  return
        items = self._items()
        if items and 0 <= self._sel < len(items):
            self._action(items[self._sel][1])
            self._draw_status()

    # ── Main loop ─────────────────────────────────────────────────────────────

    def run(self):
        self._show_splash()
        self._draw_status()
        self._screen = 'home';  self._sel = 0;  self._scroll = 0
        self._draw_menu()

        _last_status = utime.ticks_ms()
        _last_touch  = 0
        _last_ota    = utime.ticks_add(utime.ticks_ms(), -3600000)  # check soon
        _STATUS_MS   = 5000
        _OTA_MS      = 3600000   # recheck every hour
        self._running = True

        try:
            while self._running:
                now = utime.ticks_ms()

                if utime.ticks_diff(now, _last_status) >= _STATUS_MS:
                    self._draw_status()
                    _last_status = now

                # Background OTA check (non-blocking network call only when WiFi up)
                if utime.ticks_diff(now, _last_ota) >= _OTA_MS:
                    try:
                        import ota_check
                        if self._wlan and self._wlan.isconnected():
                            ota_check.check()
                            _last_ota = now
                    except Exception:
                        pass

                if utime.ticks_diff(now, _last_status) >= _STATUS_MS:
                    self._draw_status()
                    _last_status = now

                btn = self._poll_button()
                if btn == 'power':
                    self._show_screen('power')
                    self._draw_status()
                elif btn == 'ok':
                    self._beep('nav');  self._select_item()
                elif btn == 'next':
                    self._next_item()
                elif btn in ('back', 'esc'):
                    self._beep('nav');  self._go_back();  self._draw_status()
                elif btn == 'rev':
                    # long-press BOOT: kill to home
                    self._beep('nav')
                    self._prev_screens = []
                    self._screen = 'home';  self._sel = 0;  self._scroll = 0
                    self._draw_menu();  self._draw_status()

                if utime.ticks_diff(now, _last_touch) > 150:
                    ev, tx, ty = self._poll_touch()
                    if ev == 'touch':
                        self._handle_touch(tx, ty)
                        _last_touch = utime.ticks_ms()

                utime.sleep_ms(10)
                if now % 20 == 0:
                    gc.collect()

        except KeyboardInterrupt:
            pass

    def _exit(self):
        """Stop the UI loop and return control to the caller (main.py)."""
        self._running = False


# ── Module-level helpers ──────────────────────────────────────────────────────

def run(hw=None):
    if hw is None:
        import hardware_init
        hw = hardware_init.init()
    UI(hw).run()


def set_wifi(ssid, password=''):
    """REPL helper – save WiFi creds and connect immediately.

    Usage:  import ui;  ui.set_wifi('MyNet', 'MyPass')
    """
    cfg = _load_settings()
    cfg['wifi_ssid'] = ssid;  cfg['wifi_pwd'] = password
    _save_settings(cfg)
    try:
        import network
        wlan = network.WLAN(network.STA_IF)
        wlan.active(True);  wlan.connect(ssid, password)
        print("[wifi] Connecting to '{}'...".format(ssid))
        import utime as _ut
        for _ in range(20):
            _ut.sleep_ms(500)
            if wlan.isconnected():
                print("[wifi] Connected!  IP:", wlan.ifconfig()[0]);  return
        print("[wifi] Not connected yet – check password / signal")
    except Exception as e:
        print("[wifi] Error:", e)
