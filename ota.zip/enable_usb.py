# enable_usb.py  –  Restore USB CDC REPL on Genesis S3
#
# Run this when you can't get a REPL prompt via USB.
#
# How to run it when Thonny/REPL is unresponsive:
#   Option A – Upload via Thonny "Files" pane (drag & drop) then soft-reset
#   Option B – Hold BOOT during power-on → ROM bootloader, reflash fs.bin
#   Option C – Wire UART0 (TX=GPIO43 RX=GPIO44) to USB-serial adapter,
#              connect at 115200, paste the file contents
#
# What it does:
#   1. Removes the on-screen display REPL stream from dupterm slot 1
#   2. Clears any interfering sys.stdin/sys.stdout redirects
#   3. Writes a safe /boot.py that skips main.py (so you get bare REPL)
#   4. Triggers a soft-reset so the clean boot.py runs and USB CDC is fresh

import sys, uos, utime

print("=" * 40)
print("Genesis USB CDC recovery")
print("=" * 40)

# ── 1. Remove dupterm slot 1 (display stream) ─────────────────────────────────
try:
    uos.dupterm(None, 1)
    print("[OK] dupterm slot 1 cleared")
except Exception as e:
    print("[--] dupterm slot 1:", e)

# ── 2. Remove dupterm slot 0 override if any (should stay as USB CDC) ─────────
# slot 0 is the USB CDC itself – do NOT clear it, just report it
try:
    # On ESP32-S3 with native USB CDC the HAL handles slot 0 in C.
    # Calling dupterm(None, 0) would kill the REPL – we leave it alone.
    print("[OK] dupterm slot 0 (USB CDC) – left intact")
except Exception as e:
    print("[--] dupterm slot 0:", e)

# ── 3. Restore sys.stdin / sys.stdout to defaults ─────────────────────────────
try:
    # MicroPython uses a special internal object for the REPL stdin/stdout.
    # Deleting any override returns to the C-level USB CDC handler.
    if hasattr(sys, '__stdin__'):
        sys.stdin  = sys.__stdin__
    if hasattr(sys, '__stdout__'):
        sys.stdout = sys.__stdout__
    print("[OK] sys.stdin/stdout restored")
except Exception as e:
    print("[--] sys streams:", e)

# ── 4. Write a safe boot.py that skips main.py ────────────────────────────────
_SAFE_BOOT = """\
# boot.py  –  SAFE MODE  (written by enable_usb.py)
# main.py is skipped so you get a bare USB REPL.
# To restore normal boot, run:
#   import os; os.remove('/boot.py')
# or upload the original boot.py from the build.
import gc
gc.collect()
print("Safe mode boot – main.py skipped")
print("To restore: exec(open('restore_boot.py').read())")

# Raise StopIteration to prevent main.py from running
# (MicroPython skips main.py when boot.py raises StopIteration)
raise StopIteration
"""

try:
    with open('/boot.py', 'w') as f:
        f.write(_SAFE_BOOT)
    print("[OK] /boot.py replaced with safe-mode version")
except Exception as e:
    print("[--] writing boot.py:", e)

# ── 5. Write a restore script ────────────────────────────────────────────────
_RESTORE = """\
# restore_boot.py – put the original boot.py back and restart normally
import gc

_BOOT = '''
# boot.py – Genesis S3
import gc
from _boot_wifi import _connect_wifi_conf
_connect_wifi_conf()
gc.collect()
'''

with open('/boot.py', 'w') as f:
    f.write(_BOOT.strip())
print("boot.py restored – press Ctrl-D or machine.reset() to reboot")
"""

try:
    with open('/restore_boot.py', 'w') as f:
        f.write(_RESTORE)
    print("[OK] /restore_boot.py written")
except Exception as e:
    print("[--] writing restore_boot.py:", e)

# ── 6. Soft-reset into safe boot ─────────────────────────────────────────────
print()
print("Rebooting in 3 seconds into safe mode...")
print("Connect with Thonny after reset – you will get a bare REPL.")
print("Run  exec(open('restore_boot.py').read())  to restore normal boot.")
print()
utime.sleep_ms(3000)

import machine
machine.soft_reset()
