# recovery.py - Genesis S3 emergency recovery
#
# Stored on the recovery partition (/rec), separate from the main VFS.
# This partition is never touched by OTA updates.
#
# Triggered when main.py detects the UI has crashed >= 2 times in a row.
#
# What it does:
#   1. Show red recovery screen on display
#   2. Connect to WiFi using hardcoded credentials
#   3. Call ota_check.download_and_apply() to restore all VFS files
#   4. Device reboots with fresh files and crash counter cleared
#
# Dependencies: all from frozen firmware (ota_check, hardware_init, vga2_bold_16x32)

_SSID = "SASKTECH"
_PWD  = "3067570039"
_OTA_URL = "https://github.com/d31337m3/tinyos/ota.zip"

import network, utime, machine

W, H = 368, 448
_RED    = 0xF800
_WHITE  = 0xFFFF
_YELLOW = 0xFFE0
_GREEN  = 0x07E0
_BLACK  = 0x0000

_disp = None
_fnt  = None

def _init_display():
    global _disp, _fnt
    try:
        import hardware_init
        hw = hardware_init.init(skip={'sd', 'i2s', 'codec', 'user', 'fonts'})
        _disp = hw.display
        import vga2_bold_16x32 as f
        _fnt = f
        _disp.fill(_RED)
        _disp.text(_fnt, '** RECOVERY MODE **',  4, 100, _WHITE,  _RED)
        _disp.text(_fnt, 'Connecting to WiFi...',  4, 150, _YELLOW, _RED)
        _disp.show()
    except Exception as e:
        print("[recovery] display init:", e)

def _status(msg, colour=None):
    print("[recovery]", msg)
    if _disp is None:
        return
    try:
        col = colour if colour is not None else _YELLOW
        _disp.fill_rect(0, 200, W, H - 200, _RED)
        _disp.text(_fnt, msg[:22], 4, 210, col, _RED)
        _disp.show()
    except Exception as e:
        print("[recovery] display:", e)

def _progress(msg, pct=None):
    _status(msg, _YELLOW)
    if pct is not None and _disp is not None:
        try:
            bw = int(300 * max(0, min(100, pct)) // 100)
            _disp.fill_rect(34, 340, 300, 12, 0x2104)
            if bw:
                _disp.fill_rect(34, 340, bw, 12, _GREEN)
            _disp.show()
        except Exception:
            pass

def run():
    _init_display()

    # Connect WiFi
    _status("Connecting to " + _SSID)
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    utime.sleep_ms(100)
    wlan.connect(_SSID, _PWD)
    for i in range(40):
        if wlan.isconnected():
            ip = wlan.ifconfig()[0]
            _status("WiFi OK: " + ip, _GREEN)
            utime.sleep_ms(800)
            break
        utime.sleep_ms(500)
    else:
        _status("WiFi failed! Rebooting...", _WHITE)
        utime.sleep_ms(4000)
        machine.reset()
        return

    # Force OTA download and apply regardless of version
    _progress("Downloading OTA...", 5)
    try:
        import ota_check
        # Override config to force the known good URL
        ota_check.set_zip_url(_OTA_URL)
        # Bypass version check - always download in recovery
        ota_check.download_and_apply(progress_cb=_progress)
        # ^ reboots the device on success
    except Exception as e:
        _status("OTA failed: " + str(e)[:16], _WHITE)
        utime.sleep_ms(5000)
        machine.reset()


run()
