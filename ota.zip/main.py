# main.py - Genesis S3
# Boot chain: boot.py -> main.py -> ui.run(hw)
#
# Responsibilities:
#   1. OTA check (uses WiFi already connected by boot.py)
#   2. Launch UI with crash guard
#   3. If UI crashes >= 2 times, trigger recovery mode
#   4. Recovery: mount /rec partition, run recovery.py

import gc, utime, machine

_CRASH_FILE  = '/crash_count.txt'
_CRASH_LIMIT = 2

# -- Crash counter ------------------------------------------------------------

def _crash_count():
    try:
        with open(_CRASH_FILE) as f:
            return int(f.read().strip())
    except Exception:
        return 0

def _set_crash(n):
    try:
        with open(_CRASH_FILE, 'w') as f:
            f.write(str(n))
    except Exception:
        pass

def _clear_crash():
    try:
        import os
        os.remove(_CRASH_FILE)
    except Exception:
        pass

# -- OTA check ----------------------------------------------------------------

def _check_ota():
    try:
        import network
        if not network.WLAN(network.STA_IF).isconnected():
            return
        import ota_check
        result = ota_check.check(force=False)
        if result.get('available'):
            print("[main] OTA update available:", result.get('version', '?'))
            try:
                import boot_screen
                boot_screen.ota_available(result.get('version', '?'))
            except Exception:
                pass
            def _cb(msg, pct=None):
                try:
                    import boot_screen
                    boot_screen.ota_progress(msg, pct)
                except Exception:
                    pass
            ota_check.download_and_apply(progress_cb=_cb)  # reboots on success
    except Exception as e:
        print("[main] OTA check:", e)

# -- Recovery mode ------------------------------------------------------------

def _boot_recovery(hw):
    print("[main] ** RECOVERY MODE ** (UI crashed {} times)".format(_CRASH_LIMIT))
    _clear_crash()

    # Show recovery screen
    if hw and hw.display:
        try:
            import vga2_bold_16x32 as fnt
            d = hw.display
            d.fill(0xF800)
            d.text(fnt, '** RECOVERY **',  20, 160, 0xFFFF, 0xF800)
            d.text(fnt, 'Mounting /rec...',  4, 210, 0xFFE0, 0xF800)
            d.show()
        except Exception:
            pass

    # Try to mount recovery partition and run recovery.py
    try:
        import vfs as _vfs, os
        from esp32 import Partition
        rec_parts = Partition.find(Partition.TYPE_DATA, label='recovery')
        if rec_parts:
            try:
                os.mkdir('/rec')
            except OSError:
                pass
            try:
                _vfs.mount(rec_parts[0], '/rec')
            except OSError:
                # Not formatted yet - format it
                _vfs.VfsLfs2.mkfs(rec_parts[0])
                _vfs.mount(rec_parts[0], '/rec')
            try:
                with open('/rec/recovery.py') as f:
                    src = f.read()
                exec(src, {'__name__': '__main__'})
                return
            except OSError:
                print("[main] /rec/recovery.py not found - inline recovery")
        else:
            print("[main] No recovery partition found")
    except Exception as e:
        print("[main] Recovery partition error:", e)

    # Fallback: inline recovery using frozen ota_check
    _inline_recovery(hw)

def _inline_recovery(hw):
    """Last-resort recovery: force OTA download regardless of version check."""
    print("[main] Inline recovery: force OTA...")
    if hw and hw.display:
        try:
            import vga2_bold_16x32 as fnt
            d = hw.display
            d.text(fnt, 'Inline recovery...', 4, 260, 0xFFE0, 0xF800)
            d.show()
        except Exception:
            pass
    try:
        import network, ota_check
        if not network.WLAN(network.STA_IF).isconnected():
            print("[main] No WiFi for inline recovery - rebooting in 5s")
            utime.sleep_ms(5000)
            machine.reset()
            return
        # Force download even if version matches
        ota_check.download_and_apply()  # reboots on success
    except Exception as e:
        print("[main] Inline recovery failed:", e)
        utime.sleep_ms(5000)
        machine.reset()

# -- Entry point --------------------------------------------------------------

def main():
    crashes = _crash_count()

    if crashes >= _CRASH_LIMIT:
        # Need display for recovery screen - do minimal init
        try:
            import hardware_init
            hw = hardware_init.init(skip={'sd', 'i2s', 'codec', 'user', 'fonts'})
        except Exception:
            hw = None
        _boot_recovery(hw)
        return

    # Normal boot - init all hardware
    try:
        import hardware_init
        hw = hardware_init.init()
    except Exception as e:
        print("[main] hardware_init failed:", e)
        _set_crash(crashes + 1)
        utime.sleep_ms(2000)
        machine.reset()
        return

    # OTA check (non-blocking if no WiFi)
    _check_ota()

    # Finish boot screen
    try:
        import boot_screen
        boot_screen.done()
    except Exception:
        pass

    # Launch UI - set crash counter BEFORE launch, clear on clean exit
    _set_crash(crashes + 1)
    try:
        import ui
        ui.run(hw)
        # Clean exit - reset counter
        _clear_crash()
    except Exception as e:
        print("[main] UI crashed:", e)
        # Counter stays incremented - reboot to retry or trigger recovery
        utime.sleep_ms(1000)
        machine.reset()

    gc.collect()


main()
