# main.py – Genesis S3  •  On-screen REPL terminal
#
# Boot chain: boot.py → main.py
#
# Hooks into MicroPython's real REPL via uos.dupterm() so the display IS the
# REPL – full Python eval, history (↑/↓ via swipe), tab-complete, Ctrl-C/D.
# The USB/UART REPL remains active in parallel (Thonny still works).
#
# ┌──────────────────────────────────────────────────────────────────┐
# │  Terminal output  (7 rows when KB open, 13 rows when hidden)     │
# │  ...                                                             │
# ├──────────────────────────────────────────────────────────────────┤  ← sep
# │  Genesis:> ▌                      [⌨]  (tap to open keyboard)   │
# ├──────────────────────────────────────────────────────────────────┤
# │  1  2  3  4  5  6  7  8  9  0  ⌫  │  (keyboard – 5 rows)        │
# │  q  w  e  r  t  y  u  i  o  p     │                              │
# │  a  s  d  f  g  h  j  k  l  .  :  │                              │
# │  ⇧  z  x  c  v  b  n  m  _  (  )  │                              │
# │ SYM │    SPACE          │ ↵ ENTER  │                              │
# └──────────────────────────────────────────────────────────────────┘
#
# Keyboard controls:
#   Tap key          → inject character into REPL
#   ⌫               → backspace (0x7f)
#   ↵ ENTER          → carriage return
#   ⇧ SHIFT          → toggle upper/lower case
#   SYM              → symbol page  ( ! @ # $ % ^ & * + - = / \ | < > ? ' " )
#   [⌨] on sep bar   → show/hide keyboard
#   BOOT button      → hide keyboard / Ctrl-C

import uos, sys, utime, gc
import vga2_bold_16x32 as font
import hardware_init

# ── Display geometry ──────────────────────────────────────────────────────────
W,  H   = 368, 448
FW, FH  = font.WIDTH, font.HEIGHT   # 16 × 32
COLS    = W // FW                   # 23

KB_ROWS   = 5
KEY_H     = 44
KEY_W     = W // 11                 # 33 px  (11 keys across)
KB_H      = KB_ROWS * KEY_H        # 220 px
SEP_H     = FH                     # 32 px separator / prompt row
TERM_H_KB = H - KB_H - SEP_H      # 196 px = 6 text rows (KB open)
TERM_H    = H - SEP_H             # 416 px = 13 text rows (KB hidden)
MAX_LINES_KB = TERM_H_KB // FH    # 6
MAX_LINES    = TERM_H    // FH    # 13

SEP_Y = H - KB_H - SEP_H          # y of prompt/sep bar
KB_Y  = H - KB_H                  # y of keyboard top

# ── Colours ───────────────────────────────────────────────────────────────────
C_BG      = 0x0000
C_FG      = 0xFFFF
C_DIM     = 0x4228
C_HDR     = 0x07FF
C_PROMPT  = 0x07E0
C_CMD     = 0xFFE0
C_ERR     = 0xF800
C_SEP_BG  = 0x0318
C_KEY_BG  = 0x1082
C_KEY_FG  = 0xFFFF
C_KEY_SP  = 0x2945   # space bar
C_KEY_ENT = 0x0546   # enter
C_KEY_ACT = 0xFFE0   # active / pressed
C_CUR_ON  = 0xFFFF

# ── Keyboard pages ────────────────────────────────────────────────────────────
# Each page is a list of 5 rows.  Each row has exactly 11 entries.
# Special tokens:  '\x08'=backspace label, '\r'=enter, '\x00'=blank,
#                  '\x01'=shift, '\x02'=sym, '\x03'=space(wide)
_KB_LOWER = [
    ['1','2','3','4','5','6','7','8','9','0','\x08'],
    ['q','w','e','r','t','y','u','i','o','p','\x00'],
    ['a','s','d','f','g','h','j','k','l','.',':' ],
    ['\x01','z','x','c','v','b','n','m','_','(',')' ],
    ['\x02','\x03','\x03','\x03','\x03','\x03','\x03','\x03','\x03','\r','\r'],
]
_KB_UPPER = [
    ['1','2','3','4','5','6','7','8','9','0','\x08'],
    ['Q','W','E','R','T','Y','U','I','O','P','\x00'],
    ['A','S','D','F','G','H','J','K','L','.',':' ],
    ['\x01','Z','X','C','V','B','N','M','_','(',')' ],
    ['\x02','\x03','\x03','\x03','\x03','\x03','\x03','\x03','\x03','\r','\r'],
]
_KB_SYM = [
    ['!','@','#','$','%','^','&','*','+','-','\x08'],
    ['=','/','\\','|','<','>','?',"'",'\"','~','\x00'],
    ['[',']','{','}','(',')',' ','`',';',',',' ' ],
    ['\x01',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ' ],
    ['\x02','\x03','\x03','\x03','\x03','\x03','\x03','\x03','\x03','\r','\r'],
]
_KB_LABELS = {'\x08':'⌫', '\r':'↵', '\x00':' ', '\x01':'⇧', '\x02':'SY', '\x03':' '}

# ── dupterm stream ────────────────────────────────────────────────────────────

class REPLStream:
    """Stream that bridges the on-screen terminal and MicroPython's REPL."""

    def __init__(self):
        self._ibuf = bytearray()   # characters waiting to go into REPL
        self._term = None          # set after Terminal is created

    def readinto(self, buf):
        """Non-blocking read – called by REPL polling loop."""
        if not self._ibuf:
            return 0
        n = min(len(buf), len(self._ibuf))
        buf[:n] = self._ibuf[:n]
        self._ibuf = self._ibuf[n:]
        return n

    def write(self, buf):
        """Called by REPL to output text – render to terminal display."""
        if self._term:
            text = bytes(buf).decode('utf-8', 'replace') if isinstance(buf, (bytes, bytearray)) else buf
            self._term._repl_write(text)
        return len(buf)

    def inject(self, chars):
        """Feed characters as if typed by the user."""
        self._ibuf.extend(chars.encode() if isinstance(chars, str) else chars)

    def ioctl(self, req, arg):
        # 3 = POLL; return readable flag if bytes waiting
        if req == 3:
            return 1 if self._ibuf else 0
        return 0

# ── Terminal renderer ─────────────────────────────────────────────────────────

class Terminal:
    def __init__(self, disp, stream):
        self._d       = disp
        self._stream  = stream
        stream._term  = self
        self._lines   = []          # (text, colour) output ring buffer
        self._cur_line= ''          # line being built from REPL output
        self._kb_open = False
        self._kb_page = 'lower'     # 'lower' | 'upper' | 'sym'
        self._cursor  = True
        self._last_blink = utime.ticks_ms()
        self._prompt_line = ''      # last prompt + partial input echo
        self._dirty   = True

    # ── REPL output handler ────────────────────────────────────────────────

    def _repl_write(self, text):
        """Process raw REPL output including ANSI-ish escape chars."""
        for ch in text:
            if ch == '\r':
                pass                          # ignore CR in CRLF pairs
            elif ch == '\n':
                self._flush_cur()
            elif ch == '\x08':                # backspace
                self._cur_line = self._cur_line[:-1]
                self._redraw_prompt()
            else:
                self._cur_line += ch
        # Check if current line looks like a prompt (ends with '> ' or '... ')
        if self._cur_line.endswith('> ') or self._cur_line.endswith('... '):
            self._prompt_line = self._cur_line
            self._redraw_prompt()
        else:
            self._redraw_prompt()

    def _flush_cur(self):
        if self._cur_line:
            col = C_ERR if self._cur_line.startswith('Traceback') or \
                          'Error' in self._cur_line else C_FG
            self._lines.append((self._cur_line, col))
            self._cur_line = ''
            max_l = self._max_lines()
            while len(self._lines) > max_l * 6:
                self._lines.pop(0)
            self._redraw_output()

    def _max_lines(self):
        return MAX_LINES_KB if self._kb_open else MAX_LINES

    # ── Rendering ──────────────────────────────────────────────────────────

    def full_redraw(self):
        self._d.fill(C_BG)
        self._redraw_output()
        self._redraw_sep()
        if self._kb_open:
            self._redraw_keyboard()

    def _redraw_output(self):
        max_l  = self._max_lines()
        vis    = self._lines[-max_l:]
        for i in range(max_l):
            y = i * FH
            if i < len(vis):
                txt, col = vis[i]
                self._draw_text_row(y, txt, col)
            else:
                self._d.fill_rect(0, y, W, FH, C_BG)

    def _draw_text_row(self, y, text, col):
        avail = COLS - 1
        text  = (text + ' ' * avail)[:avail]
        self._d.text(font, text, 0, y, col, C_BG)

    def _redraw_sep(self):
        self._d.fill_rect(0, SEP_Y, W, SEP_H, C_SEP_BG)
        # Prompt + partial input
        label = self._prompt_line if self._prompt_line else 'Genesis:> '
        avail = COLS - 3
        label = label[-avail:]
        self._d.text(font, label, 0, SEP_Y, C_PROMPT, C_SEP_BG)
        # Cursor block
        cx = len(label) * FW
        cur_col = C_CUR_ON if self._cursor else C_SEP_BG
        self._d.fill_rect(cx, SEP_Y, FW, SEP_H, cur_col)
        # Keyboard toggle icon (top-right corner)
        icon = '\x7e\x7e' if self._kb_open else ' \x7e '
        self._d.text(font, icon, W - 3 * FW, SEP_Y, C_HDR, C_SEP_BG)

    def _redraw_prompt(self):
        self._redraw_sep()

    def blink(self):
        now = utime.ticks_ms()
        if utime.ticks_diff(now, self._last_blink) >= 500:
            self._cursor = not self._cursor
            self._last_blink = now
            self._redraw_sep()

    # ── Keyboard ───────────────────────────────────────────────────────────

    def _kb_layout(self):
        if self._kb_page == 'upper': return _KB_UPPER
        if self._kb_page == 'sym':   return _KB_SYM
        return _KB_LOWER

    def toggle_keyboard(self):
        self._kb_open = not self._kb_open
        self.full_redraw()

    def _redraw_keyboard(self):
        layout = self._kb_layout()
        for row_i, row in enumerate(layout):
            y = KB_Y + row_i * KEY_H
            col_i = 0
            while col_i < len(row):
                key = row[col_i]
                # Space bar spans cols 1-8 (7 keys wide)
                if key == '\x03':
                    if col_i == 1:
                        x = KEY_W
                        w = KEY_W * 8
                        self._draw_key(x, y, w, KEY_H, 'SPACE', C_KEY_SP)
                        col_i += 8
                        continue
                    else:
                        col_i += 1
                        continue
                # Enter spans cols 9-10 (2 keys wide)
                if key == '\r' and col_i == 9:
                    x = KEY_W * 9
                    w = W - x
                    self._draw_key(x, y, w, KEY_H, '↵', C_KEY_ENT)
                    col_i += 2
                    continue
                x  = col_i * KEY_W
                w  = KEY_W
                lbl = _KB_LABELS.get(key, key)
                bg  = C_KEY_ACT if key == '\x01' and self._kb_page == 'upper' else C_KEY_BG
                self._draw_key(x, y, w, KEY_H, lbl, bg)
                col_i += 1

    def _draw_key(self, x, y, w, h, label, bg):
        self._d.fill_rect(x + 1, y + 1, w - 2, h - 2, bg)
        lx = x + max(0, (w - FW) // 2)
        ly = y + (h - FH) // 2
        self._d.text(font, label[:1], lx, ly, C_KEY_FG, bg)

    def key_hit(self, tx, ty):
        """Map a touch inside the keyboard area to a character and inject it."""
        if not self._kb_open or ty < KB_Y:
            return
        row_i  = (ty - KB_Y) // KEY_H
        col_i  = tx // KEY_W
        if row_i < 0 or row_i >= KB_ROWS or col_i < 0 or col_i >= 11:
            return
        layout = self._kb_layout()
        if row_i >= len(layout): return
        row = layout[row_i]

        # Resolve space bar (cols 1–8) and enter (cols 9–10)
        if row_i == KB_ROWS - 1:
            if 1 <= col_i <= 8:
                self._stream.inject(' ')
                return
            elif col_i >= 9:
                self._stream.inject('\r\n')
                return
            elif col_i == 0:
                self._kb_page = 'sym' if self._kb_page != 'sym' else 'lower'
                self._redraw_keyboard()
                return

        if col_i >= len(row): return
        key = row[col_i]

        if key == '\x00':   return
        if key == '\x01':   # shift
            self._kb_page = 'upper' if self._kb_page == 'lower' else 'lower'
            self._redraw_keyboard()
            return
        if key == '\x02':   # sym
            self._kb_page = 'sym' if self._kb_page != 'sym' else 'lower'
            self._redraw_keyboard()
            return
        if key == '\x08':   # backspace
            self._stream.inject('\x7f')
            return
        if key == '\r':
            self._stream.inject('\r\n')
            # auto-switch back to lower after enter
            if self._kb_page == 'upper':
                self._kb_page = 'lower'
                self._redraw_keyboard()
            return
        self._stream.inject(key)
        # auto back to lower after typing a letter in upper
        if self._kb_page == 'upper':
            self._kb_page = 'lower'
            self._redraw_keyboard()

# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    hw    = hardware_init.init()
    disp  = hw.display
    touch = hw.touch

    try:
        from machine import Pin
        btn = Pin(0, Pin.IN, Pin.PULL_UP)
    except Exception:
        btn = None

    # ── Wire up dupterm ─────────────────────────────────────────────────────
    stream = REPLStream()
    term   = Terminal(disp, stream)

    try:
        uos.dupterm(stream, 1)   # index=1 keeps USB REPL alive on index=0
    except Exception as e:
        term._lines.append(("dupterm failed: " + str(e), 0xF800))

    # ── Launch ui first ─────────────────────────────────────────────────────
    disp.fill(0x0000)
    try:
        import ui
        ui.run(hw)
    except Exception as e:
        term._lines.append(("ui error: " + str(e), 0xF800))

    # ── Show terminal after ui exits ────────────────────────────────────────
    term.full_redraw()

    # Greet
    stream.inject('\r\n# Genesis S3 REPL – keyboard icon to type\r\n')

    _last_touch = 0

    try:
      while True:
        # Cursor blink
        term.blink()

        # ── BOOT button ──────────────────────────────────────────────────
        if btn and not btn.value():
            t0 = utime.ticks_ms()
            while not btn.value():
                utime.sleep_ms(10)
            held = utime.ticks_diff(utime.ticks_ms(), t0)
            if held < 50:
                pass
            elif held >= 1000:
                # Long press → Ctrl-C
                stream.inject('\x03')
            else:
                # Short press → hide/show keyboard
                term.toggle_keyboard()

        # ── Touch ────────────────────────────────────────────────────────
        now = utime.ticks_ms()
        if touch and utime.ticks_diff(now, _last_touch) > 120:
            try:
                t = touch.get_first_touch()
                if t:
                    _last_touch = utime.ticks_ms()
                    tx, ty = int(t[0]), int(t[1])

                    if term._kb_open and ty >= KB_Y:
                        # Keyboard area
                        term.key_hit(tx, ty)
                    elif SEP_Y <= ty < KB_Y:
                        # Sep / prompt bar → toggle keyboard
                        term.toggle_keyboard()
                    # Taps in output area are ignored (scroll future work)
            except Exception:
                pass

        gc.collect()
        utime.sleep_ms(10)

    except KeyboardInterrupt:
        # Ctrl-C from USB CDC – detach display stream and fall through to REPL
        try:
            uos.dupterm(None, 1)
        except Exception:
            pass
        print("\n[main] Ctrl-C caught – display REPL detached, USB REPL active")


main()
