# boot_screen.py – Genesis S3 boot splash, status + progress bar
#
# Reads /boot_source.json to display boot-origin badge:
#   {"source":"factory"}              → orange  [ FACTORY ]
#   {"source":"ota","version":"x.y"}  → cyan    [ OTA v1.1 ]
#   (file absent / unknown)           → grey    [ STABLE  ]
#
# All public functions are safe to call even if the display fails –
# every path is wrapped in try/except.

import utime

W, H = 368, 448

# RGB565 colours
_BLACK  = 0x0000
_WHITE  = 0xFFFF
_CYAN   = 0x07FF
_GREEN  = 0x07E0
_YELLOW = 0xFFE0
_ORANGE = 0xFD20
_RED    = 0xF800
_DGREY  = 0x2104   # dark grey  – bar background / outlines
_MGREY  = 0x630C   # mid grey   – subtitles

# Progress bar geometry
_BX = 34;  _BY = 408;  _BW = 300;  _BH = 12

_disp  = None
_font  = None
_ready = False   # True once _init() has been attempted


# ── Boot-source helpers ────────────────────────────────────────────────────────

def _boot_source():
    """Return (label_str, colour) from /boot_source.json."""
    try:
        try:
            import ujson as json
        except ImportError:
            import json
        with open('/boot_source.json') as f:
            d = json.loads(f.read())
        src = d.get('source', '')
        if src == 'factory':
            return ('FACTORY', _ORANGE)
        if src == 'ota':
            ver = d.get('version', '?')
            return ('OTA v' + ver, _CYAN)
    except Exception:
        pass
    return ('STABLE', _MGREY)


# ── Drawing helpers ────────────────────────────────────────────────────────────

def _center(s, y, fg=_WHITE, bg=_BLACK):
    if _disp is None or _font is None:
        return
    x = max(0, (W - len(s) * _font.WIDTH) // 2)
    _disp.text(_font, s[:23], x, y, fg, bg)


def _draw_splash():
    _disp.fill(_BLACK)
    _center('GENESIS  S3',     130, _CYAN,  _BLACK)
    _center('TinyOS  v1.0.0',  170, _MGREY, _BLACK)
    label, col = _boot_source()
    _center('[ ' + label + ' ]', 210, col, _BLACK)
    # empty progress-bar outline
    _disp.rect(_BX - 2, _BY - 2, _BW + 4, _BH + 4, _DGREY)
    _disp.show()


def _draw_bar(pct):
    filled = int(_BW * max(0, min(100, pct)) // 100)
    col = _GREEN if pct >= 100 else (_YELLOW if pct > 50 else _CYAN)
    _disp.fill_rect(_BX, _BY, _BW, _BH, _DGREY)
    if filled:
        _disp.fill_rect(_BX, _BY, filled, _BH, col)


def _update(msg, pct=None, fg=_WHITE):
    _disp.fill_rect(0, 378, W, 28, _BLACK)
    _center(msg[:23], 380, fg, _BLACK)
    if pct is not None:
        _draw_bar(pct)
    _disp.show()


# ── Lazy initialisation ────────────────────────────────────────────────────────

def _init():
    global _disp, _font, _ready
    if _ready:
        return _disp is not None
    _ready = True
    try:
        import hardware_init
        hw = hardware_init.init(skip={'sd', 'i2s', 'codec'})
        _disp = hw.display
        import vga2_bold_16x32 as _f
        _font = _f
        _draw_splash()
        return True
    except Exception as e:
        print('[boot_screen] init failed:', e)
        return False


# ── Public API ─────────────────────────────────────────────────────────────────

def show(msg, pct=None, colour=None):
    """Generic update – safe to call at any time."""
    if not _init():
        return
    try:
        _update(msg, pct, colour if colour is not None else _WHITE)
    except Exception as e:
        print('[boot_screen]', e)


def wifi_connecting(ssid):
    show('WiFi: ' + ssid[:17] + '...', 5, _CYAN)

def wifi_ok(ip):
    show('WiFi  ' + ip, 20, _GREEN)

def wifi_fail():
    show('No WiFi - offline mode', None, _MGREY)

def ota_checking():
    show('Checking for updates...', 30, _CYAN)

def ota_up_to_date():
    show('Firmware up to date', 100, _GREEN)

def ota_available(ver):
    show('Update v' + ver + ' found!', 35, _YELLOW)

def ota_progress(msg, pct=None):
    show(msg, pct, _YELLOW)

def ota_done():
    show('Update applied! Rebooting...', 100, _GREEN)
    utime.sleep_ms(1500)

def ota_error(msg):
    show('OTA: ' + str(msg)[:18], None, _RED)
    utime.sleep_ms(2000)

def done():
    """Clear display so the main UI starts on a blank screen."""
    if not _ready or _disp is None:
        return
    try:
        show('Starting...', 100, _GREEN)
        utime.sleep_ms(700)
        _disp.fill(_BLACK)
        _disp.show()
    except Exception:
        pass
