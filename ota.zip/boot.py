# boot.py – Genesis S3  (runs on every boot)
import gc

def _bs(fn, *a):
    """Call boot_screen.fn(*a) silently if available."""
    try:
        import boot_screen
        getattr(boot_screen, fn)(*a)
    except Exception:
        pass

def _connect_wifi_conf():
    """Parse /wifi.conf and connect to first reachable network. Returns wlan or None."""
    try:
        with open('/wifi.conf') as f:
            lines = f.read().splitlines()
    except OSError:
        return None

    networks = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if ':' in line:
            idx = line.index(':')
            ssid = line[:idx].strip()
            pwd  = line[idx+1:].strip()
            if ssid:
                networks.append((ssid, pwd))

    if not networks:
        return None

    try:
        import network, utime
        wlan = network.WLAN(network.STA_IF)
        wlan.active(True)
        utime.sleep_ms(100)
        for ssid, pwd in networks:
            print("[boot] Connecting to '{}'...".format(ssid))
            _bs('wifi_connecting', ssid)
            if pwd:
                wlan.connect(ssid, pwd)
            else:
                wlan.connect(ssid)
            for _ in range(20):
                if wlan.isconnected():
                    ip = wlan.ifconfig()[0]
                    print("[boot] WiFi OK – IP:", ip)
                    _bs('wifi_ok', ip)
                    return wlan
                utime.sleep_ms(500)
            print("[boot] '{}' timed out, trying next...".format(ssid))
        print("[boot] No networks reachable")
    except Exception as e:
        print("[boot] WiFi error:", e)

    _bs('wifi_fail')
    return None

def _try_ota(wlan):
    """Check for OTA update and apply if available. Reboots on success."""
    try:
        if wlan is None or not wlan.isconnected():
            return
        import ota_check
        _bs('ota_checking')
        result = ota_check.check(force=True)
        if result.get('available'):
            ver = result.get('version', '?')
            print("[boot] OTA update available:", ver)
            _bs('ota_available', ver)
            def _cb(msg, pct=None):
                _bs('ota_progress', msg, pct)
            ota_check.download_and_apply(progress_cb=_cb)
        else:
            print("[boot] Firmware up to date")
            _bs('ota_up_to_date')
    except Exception as e:
        print("[boot] OTA error:", e)
        _bs('ota_error', str(e))

wlan = _connect_wifi_conf()
_try_ota(wlan)
gc.collect()
_bs('done')
import main
